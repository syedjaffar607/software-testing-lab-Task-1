// src/taxi.js
export function fareForRide(distanceKm, ratePerKm) {
  return Math.round(distanceKm * ratePerKm);
}

export function totalFare(rides) {
  let sum = 0;
  for (const ride of rides) {
    sum += fareForRide(ride.distanceKm, ride.ratePerKm);
  }
  return sum;
}

export function applyPeakSurcharge(amount, percent) {
  return Math.round((amount * (100 + percent)) / 100);
}

export function waitingCharge(minutes) {
  return Math.max(0, minutes - 5) * 10;
}

export function rideSummary(rides, surchargePercent, minutesWaited) {
  const fare = totalFare(rides);
  const surcharge = applyPeakSurcharge(fare, surchargePercent) - fare;
  const waiting = waitingCharge(minutesWaited);
  return { fare, surcharge, waitingCharge: waiting, total: fare + surcharge + waiting };
}

export function totalDistance(rides) {
  let sum = 0;
  for (const ride of rides) {
    sum += ride.distanceKm;
  }
  return sum;
}
