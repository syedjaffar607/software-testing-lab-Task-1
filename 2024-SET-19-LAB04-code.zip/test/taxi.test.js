import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  fareForRide, totalFare, applyPeakSurcharge,
  waitingCharge, rideSummary, totalDistance,
} from '../src/taxi.js';

describe('R1 fareForRide', () => {
  it('multiplies distance by rate for whole numbers', () => {
    // Arrange
    const km = 10, rate = 30;
    // Act
    const result = fareForRide(km, rate);
    // Assert: 10 x 30 = 300
    assert.strictEqual(result, 300);
  });

  it('rounds a .5 fare up to the nearest rupee', () => {
    const result = fareForRide(7.5, 25);
    // 7.5 x 25 = 187.5 -> 188
    assert.strictEqual(result, 188);
  });

  it('rounds a fractional fare down when below .5', () => {
    const result = fareForRide(3.3, 10);
    // 3.3 x 10 = 33 -> 33; use 2.2 x 11 = 24.2 -> 24
    assert.strictEqual(fareForRide(2.2, 11), 24);
    assert.strictEqual(result, 33);
  });

  it('returns 0 for a zero-distance ride', () => {
    assert.strictEqual(fareForRide(0, 30), 0);
  });
});

describe('R2 totalFare', () => {
  it('adds the fares of several rides', () => {
    const rides = [
      { distanceKm: 10, ratePerKm: 30 },
      { distanceKm: 5, ratePerKm: 40 },
    ];
    // 300 + 200 = 500
    assert.strictEqual(totalFare(rides), 500);
  });

  it('returns 0 for an empty list of rides', () => {
    assert.strictEqual(totalFare([]), 0);
  });

  it('rounds each ride separately before adding (per R1)', () => {
    const rides = [
      { distanceKm: 2.5, ratePerKm: 25 },
      { distanceKm: 2.5, ratePerKm: 25 },
    ];
    // 62.5 -> 63 each, 63 + 63 = 126
    assert.strictEqual(totalFare(rides), 126);
  });
});

describe('R3 applyPeakSurcharge', () => {
  it('increases the amount by 20 percent', () => {
    // 1000 + 20% = 1200
    assert.strictEqual(applyPeakSurcharge(1000, 20), 1200);
  });

  it('rounds the surcharged amount to the nearest rupee', () => {
    // 333 x 1.10 = 366.3 -> 366
    assert.strictEqual(applyPeakSurcharge(333, 10), 366);
  });

  it('leaves the amount unchanged at 0 percent', () => {
    assert.strictEqual(applyPeakSurcharge(450, 0), 450);
  });
});

describe('R4 waitingCharge', () => {
  it('is free at 4 minutes (below the free limit)', () => {
    assert.strictEqual(waitingCharge(4), 0);
  });

  it('is free at exactly 5 minutes (boundary)', () => {
    assert.strictEqual(waitingCharge(5), 0);
  });

  it('costs Rs 10 at 6 minutes (one minute beyond the free limit)', () => {
    assert.strictEqual(waitingCharge(6), 10);
  });

  it('charges Rs 10 for each minute beyond 5 for a long wait', () => {
    // 15 - 5 = 10 minutes x 10 = 100
    assert.strictEqual(waitingCharge(15), 100);
  });
});

describe('R5 rideSummary', () => {
  it('returns fare, surcharge, waitingCharge and total', () => {
    const rides = [
      { distanceKm: 10, ratePerKm: 30 },
      { distanceKm: 5, ratePerKm: 40 },
    ];
    const result = rideSummary(rides, 10, 8);
    // fare 500; surcharge 550-500 = 50; waiting (8-5) x 10 = 30; total 580
    assert.deepStrictEqual(result, { fare: 500, surcharge: 50, waitingCharge: 30, total: 580 });
  });

  it('returns all zeros for no rides, 0% surcharge and no waiting', () => {
    assert.deepStrictEqual(rideSummary([], 0, 0),
      { fare: 0, surcharge: 0, waitingCharge: 0, total: 0 });
  });
});

describe('R6 totalDistance', () => {
  it('sums distanceKm across all rides', () => {
    const rides = [{ distanceKm: 10 }, { distanceKm: 5.5 }, { distanceKm: 4.5 }];
    // 10 + 5.5 + 4.5 = 20
    assert.strictEqual(totalDistance(rides), 20);
  });

  it('returns 0 for an empty list of rides', () => {
    assert.strictEqual(totalDistance([]), 0);
  });

  it('returns the distance of a single ride', () => {
    assert.strictEqual(totalDistance([{ distanceKm: 7 }]), 7);
  });
});
